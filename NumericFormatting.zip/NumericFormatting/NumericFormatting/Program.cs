﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericFormatting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("1️⃣ STANDARD NUMERIC FORMAT STRINGS");
            Console.WriteLine("----------------------------------------");
            Console.ResetColor();

            double number = 123456.789;

            Console.WriteLine($"Original Number: {number}\n");

            Console.WriteLine("C (Currency)      : {0:C}", number);      // ৳123,456.79
            Console.WriteLine("C0 (Currency)     : {0:C0}", number);     // ৳123,457
            Console.WriteLine("D (Decimal)       : {0:D10}", 12345);     // 0000012345
            Console.WriteLine("E (Scientific)    : {0:E}", number);      // 1.234568E+005
            Console.WriteLine("E2 (Scientific)   : {0:E2}", number);     // 1.23E+005
            Console.WriteLine("F (Fixed-point)   : {0:F}", number);      // 123456.79
            Console.WriteLine("F2 (Fixed-point)  : {0:F2}", number);     // 123456.79
            Console.WriteLine("F0 (Fixed-point)  : {0:F0}", number);     // 123457
            Console.WriteLine("G (General)       : {0:G}", number);      // 123456.789
            Console.WriteLine("N (Number)        : {0:N}", number);      // 123,456.79
            Console.WriteLine("N2 (Number)       : {0:N2}", number);     // 123,456.79
            Console.WriteLine("P (Percent)       : {0:P}", 0.1234);      // 12.34%
            Console.WriteLine("P2 (Percent)      : {0:P2}", 0.1234);     // 12.34%
            Console.WriteLine("R (Round-trip)    : {0:R}", number);      // 123456.789
            Console.WriteLine("X (Hexadecimal)   : {0:X}", 255);         // FF
            Console.WriteLine("X4 (Hexadecimal)  : {0:X4}", 255);        // 00FF
        }
    }
}
