﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PasswordChecker
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Password: ");
            string password = Console.ReadLine();

            Console.Write("Enter Password again: ");
            string confirmPassword = Console.ReadLine();

            if (!password.Equals(string.Empty))
            {
                if (!confirmPassword.Equals(string.Empty))
                {
                    if (password.Length >= 6 && confirmPassword.Length >= 6)
                    {
                        if (password.Equals(confirmPassword))
                        {
                            Console.WriteLine("Password Match!!!");
                        }
                        else
                        {
                            Console.WriteLine("Password doesn't match!!!");
                        }
                    }
                    else
                    {
                        Console.WriteLine("Password length should be 6 or more !!!");
                    }
                }
                else
                {
                    Console.WriteLine("Plese enter Confirmation Password!!!");
                }
            }
            else
            {
                Console.WriteLine("Please enter Password!!!");
            }

        }
    }
}
