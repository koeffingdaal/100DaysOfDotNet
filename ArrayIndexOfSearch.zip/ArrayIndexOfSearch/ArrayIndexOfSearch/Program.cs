﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayIndexOfSearch
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[] { 1, 1, 2, 3, 4, 6, 7, 10 };

            


            Console.Write("Enter Search Number: ");
            int.TryParse(Console.ReadLine(), out int search);

            int position = Array.IndexOf(numbers, search);

            if (position > -1)
            {
                Console.WriteLine($"The search number {search} has found and index is {position + 1}");
            }
            else
            {
                Console.WriteLine("The number has not found");
            }

            string[] stringsArray = new string[]
            {
                "Tasin", "Mim", "Habiba", "Habib"
            };

            Console.Write("Enter Search Name: ");
            string searchName = Console.ReadLine();

            int searchIndex = Array.IndexOf(stringsArray, searchName);
            if (position > -1)
            {
                Console.WriteLine($"The search Name {searchName} has found and index is {searchIndex + 1}");
            }
            else
            {
                Console.WriteLine("The Name has not found");
            }

        }
    }
}
