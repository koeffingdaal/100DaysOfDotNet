﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringLiteralFormattingInterpolation
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Escape character (\)

            string path = "C:\\Users\\wasiw\\source\\repos";
            Console.WriteLine(path);

            // Verbatim String Literal

            string source = @"C:\Users\wasiw\source\repos";
            Console.WriteLine(source);


            // String Formatting

            Console.WriteLine("What's your name?");
            string name = Console.ReadLine();
            Console.WriteLine("How old are you?");
            int age = int.Parse(Console.ReadLine());

            Console.WriteLine("My name is {0} and I'm {1} years old", name, age);

            // String Interpolation

            Console.WriteLine("Enter your University Name: ");
            string varsityName = Console.ReadLine();
            Console.WriteLine("Enter your Department Name: ");
            string department = Console.ReadLine();

            Console.WriteLine($"My University Name is {varsityName} and My department is {department}");
        }
    }
}
