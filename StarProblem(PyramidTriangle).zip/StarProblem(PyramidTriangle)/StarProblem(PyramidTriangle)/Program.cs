﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarProblem_PyramidTriangle_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter rows no: ");

            if (int.TryParse(Console.ReadLine(),out var value)) {
                
                
                for (int i = 1; i <= value; i++)
                {
                    // Printing Space
                    for (int j = 1; j <= value - i; j++)
                    {
                        Console.Write(" ");
                    }

                    // Printing Stars

                    for (int k = 1; k <= (2* i - 1); k++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();

                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
