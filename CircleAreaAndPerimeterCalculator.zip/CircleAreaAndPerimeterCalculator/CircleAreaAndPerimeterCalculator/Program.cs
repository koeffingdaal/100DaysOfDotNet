﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CircleAreaAndPerimeterCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double pi = 3.1416;

            Console.Write("Enter the radius of Circle: ");

            double radius = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("The area of circle is : " + (pi * radius * radius));
            Console.WriteLine("The Perimeter of circle is : " + (2 * pi * radius));


        }
    }
}
