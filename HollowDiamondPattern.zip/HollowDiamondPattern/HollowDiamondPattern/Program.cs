﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HollowDiamondPattern
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter rows no: ");

            if (int.TryParse(Console.ReadLine(),out var value))
            {
                for (int i = 1; i <= value; i++)
                {
                    // space
                    for (int j = 1; j <= value - i; j++)
                    {
                        Console.Write(" ");
                    }

                    // star

                    for (int k = 1; k <= i; k++)
                    {
                        Console.Write("* ");
                    }

                    // new line
                    Console.WriteLine();
                }

                for (int i = 1;i <= value - 1; i++)
                {
                    //space
                    for (int j = 1;j <= i; j++)
                    {
                        Console.Write(" ");
                    }

                    //star
                    for (int k = 1;k <= value - i; k++)
                    {
                        Console.Write("* ");
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
