﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AngleSum
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const int angleCount = 3;
            int angleSum = 0;

            int[] angles = new int[angleCount];

            for (int i = 0; i < angles.Length; i++)
            {
                Console.Write($"Enter Angle {i + 1}: ");
                int.TryParse(Console.ReadLine(), out angles[i]);
            }

            foreach (int angle in angles)
            {
                angleSum += angle;
            }

            Console.WriteLine(angleSum == 180 ? "Valid" : "Invalid");

        }
    }
}
