﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ReverseString
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter a message: ");

            string message = Console.ReadLine();

            Console.WriteLine("Print in Order: ");

            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                Thread.Sleep(150);
            }
            Console.WriteLine();
            Console.WriteLine("Print in Reverse Order: ");

            for (int i = message.Length - 1; i >= 0; i--)
            {
                Console.Write(message[i]);
                Thread.Sleep(150);
            }
        }
    }
}