﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace StringIterationLooping
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your text: ");
            string message = Console.ReadLine();

            for (int i = 0; i < message.Length; i++)
            {
                Console.Write(message[i]);
                Thread.Sleep(150);
            }

            Console.WriteLine();
            Console.Write("Find Char: ");
            char find = Convert.ToChar(Console.ReadLine());

            for (int i = 0; i < message.Length; i++)
            {
                if (message[i].Equals(find))
                {
                    Console.Write($"Yes, It is here and the index no is {i}\n");
                    
                }
            }
            
        }
    }
}
