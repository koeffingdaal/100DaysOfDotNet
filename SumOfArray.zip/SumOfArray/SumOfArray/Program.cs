﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SumOfArray
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the Count of Array : ");

            // Count Validation

            int count;

            while (!int.TryParse(Console.ReadLine(), out count) || count <= 0)
            {
                Console.Write("Invalid input! Please enter a positive integer: ");
            }
            
            Console.WriteLine();

            int[] array = new int[count];

            // Fill array with validation

            int element;

            for (int i = 0; i < count; i++)
            {
                Console.Write($"Enter {i + 1} Element in Array: ");
                while (!int.TryParse(Console.ReadLine(), out element))
                {
                    Console.Write($"Invalid input! Please enter a valid integer for element {i + 1}: ");
                }
                array[i] = element;
                
            }
            Console.WriteLine();
            
            // Array printing

            Console.Write($"The Final Array is: ");
            foreach (int item in array)
            {
                Console.Write($"{item} ");
                
            }
            Console.WriteLine();


            // Sum of Array

            int sum = 0;

            foreach (int item in array)
            {
                sum += item;
            }

            Console.WriteLine();
            Console.WriteLine($"Total Index is {array.Length} and Total Sum is: {sum}");

        }
    }
}
