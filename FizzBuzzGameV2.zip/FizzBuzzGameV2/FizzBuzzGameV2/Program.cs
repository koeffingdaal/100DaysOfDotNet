﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzzGameV2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int countFizz = 0,
                countBuzz = 0,
                countFizzBuzz = 0,
                countNumber = 0;

            int sumFizz = 0,
                sumBuzz = 0,
                sumFizzBuzz = 0,
                sumNumber = 0;

            List<int> listFizzBuzz = new List<int>();
            List<int> listFizz = new List<int>();
            List<int> listBuzz = new List<int>();
            List<int> listNumber = new List<int>();

            Console.Write("Enter FizzBuzz Game Number: ");

            if (int.TryParse(Console.ReadLine(), out var value))
            {
                if (value >= 0)
                {
                    for (int i = 1; i <= value; i++)
                    {
                        bool fizz = i % 5 == 0;
                        bool buzz = i % 7 == 0;
                        bool fizzBuzz = fizz && buzz;

                        if (fizzBuzz)
                        {
                            Console.WriteLine("FizzBuzz");
                            countFizzBuzz++;
                            sumFizzBuzz = sumFizzBuzz + i;
                            listFizzBuzz.Add(i);
                        }
                        else if (fizz)
                        {
                            Console.WriteLine("Fizz");
                            countFizz++;
                            sumFizz = sumFizz + i;
                            listFizz.Add(i);
                        }
                        else if (buzz)
                        {
                            Console.WriteLine("Buzz");
                            countBuzz++;
                            sumBuzz = sumBuzz + i;
                            listBuzz.Add(i);
                        }
                        else
                        {
                            Console.WriteLine(i);
                            countNumber++;
                            sumNumber = sumNumber + i;
                            listNumber.Add(i);
                        }
                    }
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine();
                    Console.WriteLine("The Count of Fizz Buzz: " + countFizzBuzz);
                    Console.WriteLine("The Count of Fizz : " + countFizz);
                    Console.WriteLine("The Count of Buzz : " + countBuzz);
                    Console.WriteLine("The Count of Numbers : " + countNumber);
                    Console.WriteLine();
                    Console.WriteLine("The Sum of FizzBuzz : " + sumFizzBuzz);
                    Console.WriteLine("The Sum of Buzz : " + sumBuzz);
                    Console.WriteLine("The Sum of Fizz : " + sumFizz);
                    Console.WriteLine("The Sum of Number : " + sumNumber);
                    Console.WriteLine();
                    Console.WriteLine("The FizzBuzz numbers are : " + string.Join(",", listFizzBuzz));
                    Console.WriteLine("The Fizz numbers are : " + string.Join(",", listFizz));
                    Console.WriteLine("The Buzz numbers are : " + string.Join(",", listBuzz));
                    Console.WriteLine("The Numbers are : " + string.Join(",", listNumber));
                }
                else
                {
                    Console.WriteLine("Enter Positive Value");
                }       
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }
        }
    }
}
