﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentAdmissionEligibilityChecker_Usingconst_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double minGpa = 3.2;
            const int minAge = 21;


            Console.Write("Enter your CGPA: ");
            double gpa = Convert.ToDouble(Console.ReadLine());

            Console.Write("Enter your Age: ");
            int age = Convert.ToInt32(Console.ReadLine());
            
            if (age >= minAge && gpa >= minGpa)
            {
                Console.WriteLine("Congratulations !!! you are eligible");
            }
            else
            {
                Console.WriteLine("Sorry, you are not eligible");
            }

            Console.ReadLine();
        }
    }
}
