﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace List
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter List Limit: ");
            int.TryParse(Console.ReadLine(), out var count);
            List<int> list = new List<int>(count);

            for (int i = 0; i < count; i++)
            {
                Console.Write($"Enter {i + 1} number: ");
                list.Add(Convert.ToInt32(Console.ReadLine()));
            }

            foreach (int i in list)
            {
                Console.Write($"{i}"); 
            }
        }
    }
}
