﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TryParseFunction
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Right Triangle Pattern 

            
            Console.Write("Enter Right Triangle row No: ");

            if (int.TryParse(Console.ReadLine(), out int row))
            {
                for (int i = 1;  i <= row; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write("*");
                    }
                    Console.WriteLine();
                }

            }
            else
            {
                Console.WriteLine("Invalid Input");
            }

            Console.ReadLine();



            // Floyds Triangle

            Console.Write("Enter Floyd Triangle Row No: ");

            int num = 1;

            if (int.TryParse(Console.ReadLine(),out int fRow)) 
            {
                for (int i = 1; i <= fRow; i++)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write(num + " ");
                        num++;
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }

            Console.ReadLine();


            // Reverse Triangle Pattern

            Console.Write("Enter Reverse Triangle Row No: ");

            if (int.TryParse(Console.ReadLine(),out int rRow)) 
            {
                for (int i = rRow; i >= 1; i--)
                {
                    for (int j = 1; j <= i; j++)
                    {
                        Console.Write("*"); 
                    }
                    Console.WriteLine();
                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }

            Console.ReadLine();


            // Try Parse Function without If Else

            Console.Write("Enter Try Parse No : ");
            string a = Console.ReadLine();
            int c;
            int.TryParse(a,out c);
            Console.WriteLine(c);

            Console.ReadLine();


            //Parse Function 

            Console.Write("Enter Parse No: ");
            //string input = Console.ReadLine();
            int result = int.Parse(Console.ReadLine());
            Console.WriteLine(result);

            Console.ReadLine();


            

        }
    }
}
