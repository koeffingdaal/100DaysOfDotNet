﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GradeCalculator
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter your Marks: ");
            double marks = Convert.ToDouble(Console.ReadLine());

            if (marks >= 0 && marks <= 100)
            {
                if (marks >= 95)
                {
                    Console.WriteLine("You got A+");
                }
                else if (marks >= 90)
                {
                    Console.WriteLine("You got A");
                }
                else if (marks >= 85)
                {
                    Console.WriteLine("You got B+");
                }
                else if (marks >= 80)
                {
                    Console.WriteLine("You got B");
                }
                else if (marks >= 75)
                {
                    Console.WriteLine("You got C+");
                }
                else if (marks >= 70)
                {
                    Console.WriteLine("You got C");
                }
                else if (marks >= 60)
                {
                    Console.WriteLine("You got D+");
                }
                else if (marks >= 50)
                {
                    Console.WriteLine("You got D");
                }
                else
                {
                    Console.WriteLine("You Failed");
                }
            } 
            else
            {
                Console.WriteLine("Invalid Marks");
            }



            Console.ReadLine();
        }
    }
}
