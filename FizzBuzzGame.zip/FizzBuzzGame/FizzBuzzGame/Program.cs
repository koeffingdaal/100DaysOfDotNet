﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FizzBuzzGame
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*
             * create a for loop from 1 to x
             * 3 and 5 = FizzBuzz
             * 3 = Fizz
             * 5 = Buzz
             * else = number */

            int countFizz = 0,
                countBuzz = 0,
                countFizzBuzz = 0,
                countNumber = 0;

            double sumFizz = 0,
                   sumBuzz = 0, 
                   sumFizzBuzz = 0, 
                   sumNumber = 0;

            List<int> fizzNumbers = new List<int>();
            List<int> buzzNumbers = new List<int>();
            List<int> fizzBuzzNumbers = new List<int>();
            List<int> numbers = new List<int>();


            Console.Write("Enter FizzBuzz Number : ");

            if (int.TryParse(Console.ReadLine(), out var value))
            {   


                for (int i = 1; i <= value; i++)
                {
                    bool fizz = i % 3 == 0;
                    bool buzz = i % 5 == 0;
                    bool fizzBuzz = fizz && buzz;

                    if (fizzBuzz)
                    {
                        Console.WriteLine("FizzBuzz");
                        countFizzBuzz++;
                        sumFizzBuzz += i;
                        fizzBuzzNumbers.Add(i);
                    }
                    else if (fizz)
                    {
                        Console.WriteLine("Fizz");
                        countFizz++;
                        sumFizz += i;
                        fizzNumbers.Add(i);

                        
                    }
                    else if (buzz)
                    {
                        Console.WriteLine("Buzz");
                        countBuzz++;
                        sumBuzz += i;
                        buzzNumbers.Add(i);
                    }
                    else
                    {
                        Console.WriteLine(i);
                        countNumber++;
                        sumNumber += i;
                        numbers.Add(i);
                    }
                }

                Console.WriteLine();
                Console.WriteLine("----RESULT-----");
                Console.WriteLine();

                Console.WriteLine("The Count of Fizz: " + countFizz);
                Console.WriteLine("The Count of Buzz : " + countBuzz);
                Console.WriteLine("The Count of FizzBuzz :" + countFizzBuzz);
                Console.WriteLine("The Count of Number :" + countNumber);

                Console.WriteLine();

                Console.WriteLine("The Sum of Fizz: " + sumFizz);
                Console.WriteLine("The Sum of Buzz: " + sumBuzz);
                Console.WriteLine("The Sum of FizzBuzz: " + sumFizzBuzz);
                Console.WriteLine("The Sum of Number: " + sumNumber);

                Console.WriteLine();

                Console.WriteLine("The Fizz Numbers are: " + string.Join(",", fizzNumbers));
                Console.WriteLine("The Buzz Numbers are: " + string.Join(",", buzzNumbers));
                Console.WriteLine("The FizzBuzz Numbers are: " + string.Join(",", fizzBuzzNumbers));
                Console.WriteLine("The Numbers are: " + string.Join(",", numbers));
            }
            else
            {
                Console.WriteLine("Invalid Output");
            }

            
        }
    }
}
