﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarProblem_SquareReactanglePattern_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Row No: ");
            int row = int.Parse(Console.ReadLine());

            Console.Write("Enter Col No: ");
            int col = int.Parse(Console.ReadLine());


            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < col; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
