﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimesTable
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("What times table: ");

            if (int.TryParse(Console.ReadLine(), out int value))
            {
                for (int i = 1; i <= 10;  i++)
                {
                    Console.WriteLine("{0} x {1} = {2}",value, i, (value * i));
                }
            }
            else
            {
                Console.WriteLine("Invalid Input");
            }

            Console.ReadLine();
        }
    }
}
