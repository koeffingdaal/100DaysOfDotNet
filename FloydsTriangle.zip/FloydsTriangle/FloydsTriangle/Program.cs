﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FloydsTriangle
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Row No: ");
            int row = int.Parse(Console.ReadLine());

            int num = 1;


            for (int i = 1;  i <= row; i++)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write(num + " ");
                    num++;
                }
                Console.WriteLine();
            }
        }
    }
}
