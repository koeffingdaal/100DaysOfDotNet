﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayClean
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] firstArray = new int[]
            {
                1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12
            };

            Array.Clear(firstArray, 0, firstArray.Length);

            foreach (int i in firstArray)
            {
                Console.Write($"{i} ");
            }

            Console.WriteLine();

            int[] secondArray = new int[]
            {
                1, 2, 3, 4, 5, 6, 7, 8, 9
            };

            for (int i = 3; i < secondArray.Length; i++)
            {
                secondArray[i] = default;
            }

            foreach (int i in secondArray)
            {
                Console.Write($"{i} ");

            }
        }
    }
}
