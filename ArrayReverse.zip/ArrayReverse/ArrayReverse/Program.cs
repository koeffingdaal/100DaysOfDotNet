﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrayReverse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 10, 9 };

            int[] reverseNumbers = new int[numbers.Length];

            int x = 0;

            for (int i = reverseNumbers.Length - 1; i >= 0; i--)
            {
                reverseNumbers[x] = numbers[i];
                x++;
            }

            foreach (int i in reverseNumbers)
            {
                Console.Write($"{i} ");
            }
        }
    }
}
