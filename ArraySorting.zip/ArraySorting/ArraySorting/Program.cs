﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArraySorting
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = new int[]
            {
                99,50,30,1,0,31,2,4,5,10,3,13
            };

            Array.Sort(numbers);

            foreach (int i in numbers)
            {
                Console.Write($"{i} ");
            }
        }
    }
}
