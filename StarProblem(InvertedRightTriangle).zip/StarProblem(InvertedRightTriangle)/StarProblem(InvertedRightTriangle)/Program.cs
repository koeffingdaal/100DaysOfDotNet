﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StarProblem_InvertedRightTriangle_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Row No: ");
            int row = int.Parse(Console.ReadLine());

            for (int i = row; i >= 1;  i--)
            {
                for (int j = 1; j <= i; j++)
                {
                    Console.Write("*");
                }
                Console.WriteLine();
            }
        }
    }
}
