﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EvenOddChecker
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your Number:");
            int firstNum = int.Parse(Console.ReadLine());

            if (firstNum % 2 == 0)
            {
                Console.WriteLine("Number is Even");
            }else
            {
                Console.WriteLine("Number is Odd");
            }



        }
    }
}
